package classes;
/**
 * @author Canner Enbatan
 */
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

	public class brickView {
		
		private boolean destroyed;
		public static int height = 0;
		public static int width = 0;
		public static boolean hitted = false;
		Image image;
		public int x ;
		public int y;
		public brickView(int x, int y){
			 ImageIcon im= new ImageIcon("3dbricks.jpg");
			 image = im.getImage();
			
			height = image.getHeight(null);
			width = image.getWidth(null);
			
			this.x = x;
			this.y = y;
			
			destroyed = false;
			hitted = false;
		}
		
		public int getWidth(){
			return width;
		}
		public int getHeight(){
			return height;
		}
		
		public boolean isHitted(){
			return hitted;
		}
		
		public void setHit(boolean flag){
			hitted = flag;
		}
		
		 public boolean isDestroyed() {
		        
		        return destroyed;
		    }

		    public void setDestroyed(boolean val) {
		        
		        destroyed = val;
		    }
		    Rectangle getRect() {
		        return new Rectangle(x, y,
		                image.getWidth(null), image.getHeight(null));
		    }
		
	}