package classes;
/**
 * @author Caner Enbaten
 */
import java.awt.EventQueue;
import javax.swing.JFrame;

public class breakOutGame extends JFrame {

    public breakOutGame() {
        
        initUI();
    }
    
    private void initUI() {
        
        add(new levelview());
        setTitle("Breakout");
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(VariableController.width, VariableController.height);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    public static void main(String[] args) {
        
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {                
                breakOutGame game = new breakOutGame();
                game.setVisible(true);                
            }
        });
    }
}