package classes;
/**
 * Canner Enbatan
 */

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class BrickMenuController implements ActionListener
{
	private BrickMenuView menuview;
	private BrickMenuModel menumodel;
	

public BrickMenuController(BrickMenuView menuview,BrickMenuModel menumodel)
{
	this.menumodel = menumodel;
	this.menuview = menuview;	
	//this.optionview = optionview;
	
}

public void actionPerformed(ActionEvent e)
{
	String command = e.getActionCommand();
	if(command == "Start")
	{
	menumodel.changefromMenutoPanel1(2);
	menuview.displayPanel(menumodel.whichPanel());
    }
	
	if(command == "Options")
	{
		menumodel.changefromMenutoPanel1(3);
		menuview.displayPanel(menumodel.whichPanel());
		
	}
	
	if(command == "Credits")
	{
		//System.out.println("creditssss");
		menumodel.changefromMenutoPanel1(4);
		menuview.displayPanel(menumodel.whichPanel());
	}
	
	
	// taking the command from option
	if(command == ("Exit"))
	{
		System.out.println("Exit button was presssed");
		menumodel.changefromCredittoMenu(6);
		menuview.displayPanel(menumodel.whichPanel2());
		//optionview.displayPanel(menuview.whichPanel());
	}
	
	if(command == ("Exit.."))
	{
		System.out.println("level1 Exit button was presssed");
		menumodel.changefromLevel1toMenu(7);
		menuview.displayPanel(menumodel.whichPanel3());
		//optionview.displayPanel(menuview.whichPanel());
	}
}
}


