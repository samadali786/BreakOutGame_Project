package classes;
/**
 * 
 * @author Canner Enbatan
 *
 */


public interface VariableController {
		
	//the variables for the width and height of the window
		public static final int width = 500;
	    public static final int height = 450;
	    
	//the bottom of the window
	    public static final int bottom = 390;
	    
	//the start of the paddle positions
	    public static final int startPaddleX = 200;
	    public static final int startPaddleY = 360;
	    
	//the start of the ball positions
	    public static final int startBallX = 230;
	    public static final int startBallY = 355;    
	    
	//the timer variables
	    public static final int DELAY = 1000;
	    public static final int PERIOD = 10;
}
