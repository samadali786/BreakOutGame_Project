package classes;
import javax.swing.ImageIcon;
/**
 * 
 * @author Tyler and Canner
 *
 */
public class ball extends ImageController implements VariableController {

    private int xdir;
    private int ydir;

    public ball() {

        xdir = 1;
        ydir = -1;

        ImageIcon ii = new ImageIcon("bal2.jpg");
        image = ii.getImage();

        i_width = image.getWidth(null);
        i_heigth = image.getHeight(null);

        resetState();
    }

    public void move() {
        
        x += xdir;
        y += ydir;

        if (x == 0) {
            setXDir(1);
        }

        if (x == width - i_width) {
            setXDir(-1);
        }

        if (y == 0) {
            setYDir(1);
        }
    }

    private void resetState() {
        
        x = startBallX;
        y = startBallY;
    }

    public void setXDir(int x) {
        xdir = x;
    }

    public void setYDir(int y) {
        ydir = y;
    }

    public int getYDir() {
        return ydir;
    }
}