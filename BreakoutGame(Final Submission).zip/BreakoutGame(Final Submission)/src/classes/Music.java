package classes;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import sun.audio.*;
import java.io.*;
/**
 * 
 * @author Samad Ali trying to achciving a music part
 *
 */
public class Music 
{
	public static void main (String[] args)
	{
		MusicController controller = new MusicController();
		  JFrame frame = new JFrame();
		  frame.setSize(200,200);
		  JButton music = new JButton("On/OFF");
		  frame.add(music);
		//  music.addActionListener(new AL());
		  frame.show(true);
	}

	
	

}