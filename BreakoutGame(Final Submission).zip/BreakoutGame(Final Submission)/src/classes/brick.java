package classes;
/**
 * @author Caner Enbatan
 */
import java.awt.EventQueue;

	import javax.swing.JFrame;

	public class brick extends JFrame {
		
		public static final int WIDTH = 400;
	    public static final int HEIGTH = 400;
	    public static brickModel model = new brickModel(1);
	    public static brickView view = new brickView(0, 0);
	    public static levelview levelview = new levelview();
	    public brick() {
	        
	        initUI();
	    }
	    
	    private void initUI() {
	        
	    	@SuppressWarnings("unused")
			brickController controller = new brickController(model, view, levelview);
	    	
	        add(levelview);
	        setTitle("Breakout");
	        
	        setDefaultCloseOperation(EXIT_ON_CLOSE);
	        setSize(WIDTH, HEIGTH);
	        setLocationRelativeTo(null);
	        setResizable(false);
	        setVisible(true);
	    }

	    public static void main(String[] args) {
	        
	        EventQueue.invokeLater(new Runnable() {
	            @Override
	            public void run() {                
	                brick game = new brick();
	                game.setVisible(true);                
	            }
	        });
	    }
	}
