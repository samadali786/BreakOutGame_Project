package classes;
/**
 * @author Samad Ali
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.font.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OptionView extends JPanel
{
	
	private JButton musicBotton; 
	private JLabel musicLabel; 
    //private javax.swing.JLabel JLabeloption;
    


public OptionView()
{
	 
	
   //JLabeloption = new JLabel();

// jLabel for option 
	
	musicLabel = new JLabel("Option Menu");
	musicLabel.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	musicLabel.setBounds(180, 10, 190, 40);
	musicLabel.setForeground(Color.GREEN);
	add(musicLabel);
	

	

// jLabel for music
	musicLabel = new JLabel("Sound:");
	musicLabel.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	musicLabel.setBounds(90, 190, 190, 40);
	musicLabel.setForeground(Color.GREEN);
	add(musicLabel);
	
	
	

// jLabel for exit to menu
		musicLabel = new JLabel("back to menu:");
		musicLabel.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
		musicLabel.setBounds(85, 290, 190, 40);
		musicLabel.setForeground(Color.GREEN);
		add(musicLabel);
	
}
}
