package classes;
/**
 * @author Fuzzail Gillani
 */
import java.util.*;
import java.awt.*;
import java.io.*;

public class LevelController{
	LevelModel model;
	levelview view;
	public LevelController(LevelModel modelParam, levelview viewParam){
		model = modelParam;
		view = viewParam;
	}
	
	public void initializeNextLevel() throws IOException{
		ArrayList<Point> coordinates = new ArrayList<Point>();
		BufferedReader fileReader = new BufferedReader(new FileReader(model.fileNames.get(0)));
		String line;
		int x;
		int y;
		line = fileReader.readLine();
		model.ballSpeed = line;
		line = fileReader.readLine();
		model.numOfSpecialBricks = line;
		//while((line = fileReader.readLine()) != null){
		x = Integer.parseInt(fileReader.readLine());
		y = Integer.parseInt(fileReader.readLine());
		model.bricks = new Point(x,y);
		//}
		//model.bricks = coordinates;
		
		//File file = new File(model.fileNames.get(0));
		//Scanner scanner = new Scanner(file);
		//model.ballSpeed = scanner.nextLine();
		//model.numOfSpecialBricks = scanner.nextLine();
		//while(scanner.hasNextLine()){
		//	String line = scanner.nextLine();
		//	model.bricks.add(readPoint(line));
		//}
		//scanner.close();
		
		
		//int i = 0;
		//for(Point p : coordinates){
		//	double ran = Math.random() * (coordinates.size() - i) + 1;
		//	if (ran <= model.numOfSpecialBricks){
		//		SpecialBrickModel modelParam = new SpecialBrickModel();
		//		SpecialBrickView viewParam = new SpecialBrickView();
		//		model.bricks.add(new SpecialBrickController(modelParam, viewParam);
		//		i++;
		//		model.numOfSpecialBricks--;
		//	}
		//	BrickModel modelParam = new BrickModel();
		//	BrickView viewParam = new BrickView();
		//	model.bricks.add(new BrickController(modelParam, viewParam);
		//}
		//model.fileNames.remove(0);
	}

	Point readPoint(String line){
		String coord[] = line.split(",");
		return new Point(Integer.parseInt(coord[0]),Integer.parseInt(coord[1]));
	}
	
	public void setView(){
		view.setNum(model.numOfSpecialBricks);
		view.setSpeed(model.ballSpeed);
		//view.setpoints(model.bricks);
	//	view.initBoard(model.bricks);
	}

	//public void removeBrick(Brick brick){
	//	int i = 0;
	//	for(BrickController b : model.bricks){
	//		if(b.equals(brick)){
	//			model.bricks.remove(i);
	//			if(levelComplete())
	//				endLevel();
	//			break;
	//		}
	//	i++;
	//	}
	//}

	//public void endLevel(){
	//	if(model.fileNames.isEmpty())
	//		endGame();
	//	else
	//		initializeNextLevel();
	//}
	
	//public boolean levelComplete(){
	//	return model.bricks.isEmpty();
	//}
	
	public void endGame(){
		//TODO end game code
	}
}