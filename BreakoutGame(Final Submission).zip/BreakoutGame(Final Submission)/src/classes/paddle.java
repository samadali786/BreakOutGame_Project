package classes;
/**
 * @author Eliazor Sanchez, Canner Enbatan
 */
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class paddle extends ImageController implements VariableController {
	 
	private int dx;

    public paddle() {

        ImageIcon ii = new ImageIcon("ped 3d.png");
        image = ii.getImage();

        i_width = image.getWidth(null);
        i_heigth = image.getHeight(null);

        startState();
    }

    public void movePaddle() {

        x += dx;

        if (x <= 0) {
            x = 0;
        }

        if (x >= width - i_width) {
            x = width - i_width;
        }
    }

    public void keyPressed(KeyEvent e) {

        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            dx = -1;
        }

        if (key == KeyEvent.VK_RIGHT) {
            dx = 1;
        }
    }

    public void keyReleased(KeyEvent e) {

        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT) {
            dx = 0;
        }

        if (key == KeyEvent.VK_RIGHT) {
            dx = 0;
        }
    }

    private void startState() {

        x = startPaddleX;
        y = startPaddleY;
    }
	
}
