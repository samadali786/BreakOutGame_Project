package classes;
/**
 * 
 * @author Samad Ali
 *
 */
public class BrickMenuModel
{
	 private int menupanel;
	 private int optionviewexit;
	 private int creditviewexit;
	 private int level1exit;

	 public BrickMenuModel() 
	    {
		    menupanel = 1;
	        optionviewexit = 5;
	        creditviewexit = 6;
	        level1exit = 7;
	    }

	    /**
	     * @return the value of panel
	     */
	  public int whichPanel() 
	    {
	    	if(optionviewexit == 5)
	    	{
	        return menupanel;
	    	}
	    	
	    	
	    	else
	    	{
	    		return optionviewexit;
	    	}
	    	
	    	
	    }   
	    
	    
	  /**
	     * @return the value of menupanel from exiting credit panel 
	     */
	    public int whichPanel2()
	    {
	    	if(creditviewexit == 6)
	    	{
	        return menupanel;
	    	}
	    	
	    	
	    	else
	    	{
	    		return creditviewexit;
	    	}
	    }  
			
	    public int whichPanel3()
	    {
	    	if(level1exit == 6)
	    	{
	        return menupanel;
	    	}
	    	
	    	
	    	else
	    	{
	    		return level1exit;
	    	}
	    }  
			
	    
	    
	     /**
	     * Switch panel from menu start button to level1 
	     */
	    public void changefromMenutoPanel1(int panelValue) 
	    {
	        menupanel = panelValue; // first level start
	      
	    }
	    
	    
	    // switch from option menu to main menu
	    
	   public void changefromOptiontoMenu()
	   {
	        if (menupanel == 1)
	            menupanel = 5;
	   
	        else menupanel = 1;
	        
	        
	       
	            
	    }
	   
	  //  switch from credit to main menu 
	   public void changefromCredittoMenu()
	   {
	        if (menupanel == 1)
	            menupanel = 6;
	   
	        else menupanel = 1;
	      
	        
	       
	            
	    }
	   
	   
	//  switch from level1 to main menu 
		   public void changefromLevel1toMenu()
		   {
		        if (menupanel == 1)
		            menupanel = 7;
		   
		        else menupanel = 1;
		        
		        
		       
		            
		    }
	   
	   
	   
	  // these methods change from each panels to main menu  
	    public void changefromOptiontoMenu(int backtomainmenu  )
	    {
	    	  menupanel = backtomainmenu;
	    	  optionviewexit = backtomainmenu;
	    	
	    }
	    
	    public void changefromCredittoMenu(int backtomainmenu  )
	    {
	    	  menupanel = backtomainmenu;
	    	  creditviewexit = backtomainmenu;
	    	
	    }
	    
	    public void changefromLevel1toMenu(int backtomainmenu  )
	    {
	    	  menupanel = backtomainmenu;
	    	  level1exit = backtomainmenu;
	    	
	    }
	    
	    
	    
	    
	}
