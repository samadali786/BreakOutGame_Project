package classes;
/**
 * @author Samad Ali, Canner Enbatan, Eliazor Sanchez, Fuzzail Gillani, Tyler Worch
 */

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.util.Timer;
import java.util.TimerTask;


public class levelview extends JPanel implements VariableController 
{
	
	 private int BRICKNUMBER = 24;
	 private Timer timer;
	 private paddle paddle;
	 private ball ball;
	 private brickView bricks[];
	 private boolean ingame = true;
	 private int numOfRows = 4;
	 private int numOfCols = 6;
	 private String message = "Game Over";

	 private JLabel jLabel5;
	 private JLabel jLabel6;
	 private JLabel jLabel7;
	 private JLabel jLabel8;
	 private String numOfSpecialBricks;
	 private String ballSpeed;
	 private String points;
	 
	 private BufferedImage image;

	  
	  
	   
	 public void setNum(String i){
		 numOfSpecialBricks = i;
		 jLabel6.setText("Number of Special Bricks: " + numOfSpecialBricks + "\n");
	 }

	 public void setSpeed(String i){
		 ballSpeed = i;
		 jLabel7.setText("Ball Speed: " + ballSpeed + "\n");
	 }
	 
	
	 public levelview()

	 {
		 
		 
		  initBoard();
		 
		 
		 try {                
	          image = ImageIO.read(new File("breaklevel1.jpg"));
	       } catch (IOException ex) {
	            // handle exception...
	       }

		  this.setBackground(Color.BLACK);
		  this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
	      jLabel5= new JLabel();
	 	  jLabel5.setBackground(new java.awt.Color(0, 0, 0));
	      jLabel5.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30)); // NOI18N
	      jLabel5.setForeground(new java.awt.Color(255, 0, 0));
	      jLabel5.setText("Level1");
	      add(jLabel5);
	      jLabel5.setBounds(5, 0,200, 40);
	           
	      jLabel6= new JLabel();
	 	  jLabel6.setBackground(new java.awt.Color(0, 0, 0));
	      jLabel6.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 10)); // NOI18N
	      jLabel6.setForeground(new java.awt.Color(255, 0, 0));
	      jLabel6.setText("");
	      add(jLabel6);
	      jLabel6.setBounds(8, 20, 190, 40);
	      
	      jLabel7= new JLabel();
	 	  jLabel7.setBackground(new java.awt.Color(0, 0, 0));
	      jLabel7.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 10)); // NOI18N
	      jLabel7.setForeground(new java.awt.Color(255, 0, 0));
	      jLabel7.setText("");
	      add(jLabel7);
	      jLabel7.setBounds(8, 35, 190, 40);
	      
	      jLabel8= new JLabel();
	 	  jLabel8.setBackground(new java.awt.Color(0, 0, 0));
	      jLabel8.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 10)); // NOI18N
	      jLabel8.setForeground(new java.awt.Color(255, 0, 0));
	      jLabel8.setText("");
	      add(jLabel8);
	      jLabel8.setBounds(9, 50, 190, 40);
	      
	      
	      
	      
	 }
	 
	
public void initBoard() {
	addKeyListener(new TAdapter());
    setFocusable(true);
   //numOfRows = bricksSize.x;
   //numOfCols = bricksSize.y;
   // BRICKNUMBER = numOfRows * numOfCols;
    bricks = new brickView[BRICKNUMBER];
    setDoubleBuffered(true);
    timer = new Timer();
    timer.scheduleAtFixedRate(new ScheduleTask(), DELAY, PERIOD);
		        
}

 @Override
public void addNotify() {

    super.addNotify();
    gameInit();
}

private void gameInit() {

	ball = new ball();
    paddle = new paddle();
		    	
    int k = 0;
		    	
		        
    for (int i = 0; i < numOfRows; i++) {
	 for (int j = 0; j < numOfCols; j++) {
		 bricks[k] = new brickView(j * 60 + 60, i * 25 + 60);
		 k++;
		 }
	 }
    }
		            
		                
		    

		    @Override
public void paintComponent(Graphics g) {
	super.paintComponent(g);

    Graphics2D g2d = (Graphics2D) g;

	g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
		                RenderingHints.VALUE_ANTIALIAS_ON);

    g2d.setRenderingHint(RenderingHints.KEY_RENDERING,
		                RenderingHints.VALUE_RENDER_QUALITY);

    if (ingame) {
    	drawObjects(g2d);
    	} else {
    		gameFinished(g2d);
		}

		    Toolkit.getDefaultToolkit().sync();
	    }
		    
 private void drawObjects(Graphics2D g2d) {
	 g2d.drawImage(ball.getImage(), ball.getX(), ball.getY(),
			 ball.getWidth(), ball.getHeight(), this);
     g2d.drawImage(paddle.getImage(), paddle.getX(), paddle.getY(),
		     paddle.getWidth(), paddle.getHeight(), this);
		
     for (int i = 0; i < BRICKNUMBER; i++) {
    	 if (!bricks[i].isDestroyed()) {
    		 g2d.drawImage(bricks[i].image, bricks[i].x,
		            bricks[i].y, bricks[i].getWidth(),
		            bricks[i].getHeight(), this);
		                
		            }
		        }	        
}	    
 private void gameFinished(Graphics2D g2d) {

		        Font font = new Font("Verdana", Font.BOLD, 18);
		        FontMetrics metr = this.getFontMetrics(font);

		        g2d.setColor(Color.BLACK);
		        g2d.setFont(font);
		        g2d.drawString(message,
		                (VariableController.width - metr.stringWidth(message)) / 2,
		                VariableController.width / 2);
		    } 
private class TAdapter extends KeyAdapter {

		        @Override
		        public void keyReleased(KeyEvent e) {
		            paddle.keyReleased(e);
		        }

		        @Override
		        public void keyPressed(KeyEvent e) {
		            paddle.keyPressed(e);
		        }
		    }

 private class ScheduleTask extends TimerTask {

		        @Override
		        public void run() {

		            ball.move();
		            paddle.movePaddle();
		            checkCollision();
		            repaint();
		        }
		    }
		    private void stopGame() {

		        ingame = false;
		        timer.cancel();
		       
		    }
private void checkCollision() {
		    	JTextArea area = new JTextArea("Victory");
		    	area.setForeground(Color.RED);

		            if (ball.getRect().getMaxY() > VariableController.bottom) {
		                stopGame();
		            }

		            for (int i = 0, j = 0; i < BRICKNUMBER; i++) {
		                
		                if (bricks[i].isDestroyed()) {
		                    j++;
		                }
		                
		                if (j == BRICKNUMBER) {
		                    message = "";
		                    stopGame();
		                }
		            }

		            if ((ball.getRect()).intersects(paddle.getRect())) {

		                int paddleLPos = (int) paddle.getRect().getMinX();
		                int ballLPos = (int) ball.getRect().getMinX();

		                int first = paddleLPos + 8;
		                int second = paddleLPos + 16;
		                int third = paddleLPos + 24;
		                int fourth = paddleLPos + 32;

		                if (ballLPos < first) {
		                    ball.setXDir(-1);
		                    ball.setYDir(-1);
		                }

		                if (ballLPos >= first && ballLPos < second) {
		                    ball.setXDir(-1);
		                    ball.setYDir(-1 * ball.getYDir());
		                }

		                if (ballLPos >= second && ballLPos < third) {
		                    ball.setXDir(0);
		                    ball.setYDir(-1);
		                }

		                if (ballLPos >= third && ballLPos < fourth) {
		                    ball.setXDir(1);
		                    ball.setYDir(-1 * ball.getYDir());
		                }

		                if (ballLPos > fourth) {
		                    ball.setXDir(1);
		                    ball.setYDir(-1);
		                }
		            }

		            for (int i = 0; i < BRICKNUMBER; i++) {
		                
		                if ((ball.getRect()).intersects(bricks[i].getRect())) {

		                    int ballLeft = (int) ball.getRect().getMinX();
		                    int ballHeight = (int) ball.getRect().getHeight();
		                    int ballWidth = (int) ball.getRect().getWidth();
		                    int ballTop = (int) ball.getRect().getMinY();

		                    Point pointRight = new Point(ballLeft + ballWidth + 1, ballTop);
		                    Point pointLeft = new Point(ballLeft - 1, ballTop);
		                    Point pointTop = new Point(ballLeft, ballTop - 1);
		                    Point pointBottom = new Point(ballLeft, ballTop + ballHeight + 1);

		                    if (!bricks[i].isDestroyed()) {
		                        if (bricks[i].getRect().contains(pointRight)) {
		                            ball.setXDir(-1);
		                        } else if (bricks[i].getRect().contains(pointLeft)) {
		                            ball.setXDir(1);
		                        }

		                        if (bricks[i].getRect().contains(pointTop)) {
		                            ball.setYDir(1);
		                        } else if (bricks[i].getRect().contains(pointBottom)) {
		                            ball.setYDir(-1);
		                        }

		                        bricks[i].setDestroyed(true);
		    }
		}
	}
   }
		        
		    
 }

	 
