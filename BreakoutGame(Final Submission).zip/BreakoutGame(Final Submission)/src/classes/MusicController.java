package classes;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.IOException;

import sun.audio.AudioData;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;
import sun.audio.ContinuousAudioDataStream;
/**
 * 
 * @author Samad Ali trying to acheiving a music part  
 *
 */
public class MusicController implements ActionListener
{
	public final void actionPerformed(ActionEvent e)
	{
		music();
	}
	
	


public static void music()
{
	AudioPlayer MGP = AudioPlayer.player;
	AudioStream BGM;
	AudioData MD;
	ContinuousAudioDataStream loop = null;	
	
	try
	{
	BGM = new AudioStream(new FileInputStream("chiptune.wav"));
	MD = BGM.getData();
	loop = new ContinuousAudioDataStream(MD);
	}
	catch(IOException error)
	{
		
		
		
	}
	
	MGP.start(loop);
}
}
