package classes;
/**
 * 
 * @author Canner Enbatan
 *
 */
public class brickController {

	private brickModel model;
	private brickView view;
	private levelview levelview;
	
	
	public brickController(brickModel model, brickView view, levelview levelview){
		this.model = model;
		this.view = view;
		this.levelview = levelview;
	}
}
