package classes;
/**
 * @author Samad Ali
 */
import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;



public class CreditPanelview extends JPanel
{
	   private JLabel jcreditLabel4;
	   private JLabel jnameLabel;
	   private JLabel jname1Label;
	   private JLabel jname2Label;
	   private JLabel jname3Label;
	   private JLabel jname4Label;
	   private JLabel jname5Label;
	   
	  
	   
	   


public CreditPanelview()
{
	

	jnameLabel = new JLabel("Credits");
	jnameLabel.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	jnameLabel.setBounds(195, 10, 190, 40);
	jnameLabel.setForeground(Color.GREEN);
	add(jnameLabel);
	
	
	

	jcreditLabel4 = new JLabel("Name:");
	jcreditLabel4.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	jcreditLabel4.setBounds(50, 150, 190, 40);
	jcreditLabel4.setForeground(Color.GREEN);
	add(jcreditLabel4);
	
	
	
	
	
	jname1Label = new JLabel("-Samad Ali");
	jname1Label.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	jname1Label.setBounds(90, 200, 190, 40);
	jname1Label.setForeground(Color.GREEN);
	add(jname1Label);
	
	
	jname2Label = new JLabel("-Fuzail");
	jname2Label.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	jname2Label.setBounds(90, 230, 190, 40);
	jname2Label.setForeground(Color.GREEN);
	add(jname2Label);
	
	
	
	jname3Label = new JLabel("-Tyler");
	jname3Label.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	jname3Label.setBounds(90, 260, 190, 40);
	jname3Label.setForeground(Color.GREEN);
	add(jname3Label);
	
	
	jname4Label = new JLabel("-Eliasor");
	jname4Label.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	jname4Label.setBounds(90, 290, 190, 40);
	jname4Label.setForeground(Color.GREEN);
	add(jname4Label);
	
	
	jname5Label = new JLabel("-Caner");
	jname5Label.setFont(new java.awt.Font("Tw Cen MT Condensed", 1, 30));
	jname5Label.setBounds(90, 320, 190, 40);
	jname5Label.setForeground(Color.GREEN);
	add(jname5Label);
	
	
	
      
	
}


}


