package classes;
/**
 * @author Fuzzail Gillani
 */
import java.util.*;
import java.awt.*;
public class LevelModel{
	ArrayList<String> fileNames;
	Point bricks;
	String numOfSpecialBricks;
	String ballSpeed;
	
	public LevelModel(ArrayList<String> levelFiles){
		fileNames = levelFiles;
	}

}
