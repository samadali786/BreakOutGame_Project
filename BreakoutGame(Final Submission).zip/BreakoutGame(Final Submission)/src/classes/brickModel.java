package classes;
/**
 * 
 * @author Canner Enbatan
 *
 */
public class brickModel {

		private int model = 1;
		public brickModel(int model){
			this.model = model;
		}
		
		public int getModel(){
			return model;
		}
		
		public void setModel(int model){
			this.model = model;
		}
	}


