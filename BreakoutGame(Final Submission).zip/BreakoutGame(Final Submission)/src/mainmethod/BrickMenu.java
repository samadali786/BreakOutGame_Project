package mainmethod;

import classes.BrickMenuController;
import classes.BrickMenuModel;
import classes.BrickMenuView;
import classes.VariableController;
import classes.levelview;
import java.awt.EventQueue;
import java.io.IOException;

import javax.swing.JFrame;

/**
 * @author Eliazar Sanchez
 * @author Samad Ali
 * @author Caner Enbaten
 * @author Fuzail Giliani
 * @author Tyler Worch
 *         
 * @date December 7, 2016
 * 
 * @project BreakOut Game!!
 * 
 * @teamName S.T.E.C.F
 * 
 * @course UTSA course CS-3443
 * 
 * @caveats We have the menu and game functionality running together with the 20 classes, yet it is
 * displayed in two separate JFrames as well as music part as we ran out of time and could'nt finish connecting the two together,
 * moreover we also able to implements all game components connected to main menu levels when start button hits
 */
public class BrickMenu extends JFrame  {

	
    public BrickMenu() {
        
        try {
			initUI();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    private void initUI() throws IOException {
        
        add(new levelview());
        setTitle("Breakout");
        BrickMenuModel model = new BrickMenuModel();
		BrickMenuView view = new BrickMenuView();
		BrickMenuController controller = new BrickMenuController(view, model);
		
		
	    view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    view.setSize(500,450);
	    view.setVisible(true);
	    view.register(controller);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(VariableController.width, VariableController.height);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    public static void main(String[] args) {
        
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {                
                BrickMenu game = new BrickMenu();
                game.setVisible(true);                
            }
        });
    }
}